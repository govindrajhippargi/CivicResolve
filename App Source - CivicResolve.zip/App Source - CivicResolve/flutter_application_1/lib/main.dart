import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'splash_screen.dart';
import 'language_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  await Supabase.initialize(
    url: 'https://ooryormddgyvgthggnzo.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9vcnlvcm1kZGd5dmd0aGdnbnpvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTgzNzQyNzIsImV4cCI6MjA3Mzk1MDI3Mn0.fkqBfcvgYy90HfJWPrqBnNSTCbIzlSN9c0QpE7eYavg',
  );
  
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final LanguageService _languageService = LanguageService();

  @override
  void initState() {
    super.initState();
    _languageService.addListener(_onLanguageChanged);
  }

  @override
  void dispose() {
    _languageService.removeListener(_onLanguageChanged);
    super.dispose();
  }

  void _onLanguageChanged() {
    setState(() {
      // Rebuild the entire app when language changes
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CivicResolve',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF3B82F6), // Bright blue
        ),
        useMaterial3: true,
        fontFamily: 'Inter', // Clean sans-serif font
      ),
      home: const SplashScreen(),
      debugShowCheckedModeBanner: false,
      // Add locale support for the selected language
      locale: Locale(_languageService.currentLanguage.code),
      supportedLocales: LanguageService.supportedLanguages
          .map((language) => Locale(language.code))
          .toList(),
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
    );
  }
}
