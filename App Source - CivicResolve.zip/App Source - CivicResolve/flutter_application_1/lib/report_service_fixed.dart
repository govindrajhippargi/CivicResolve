import 'package:supabase_flutter/supabase_flutter.dart';
import 'auth_service_fixed.dart';

class ReportService {
  static final SupabaseClient _supabase = Supabase.instance.client;
  static final AuthService _authService = AuthService.instance;
  static ReportService? _instance;
  static ReportService get instance => _instance ??= ReportService._();
  
  ReportService._();

  // Submit a new report (linked to logged-in user)
  Future<ReportSubmissionResult> submitReport({
    required String title,
    required String description,
    required String category,
    required String location,
    double? latitude,
    double? longitude,
    List<String>? imageUrls,
    String? contactNumber,
  }) async {
    try {
      // Check if user is logged in
      if (!_authService.isLoggedIn) {
        return ReportSubmissionResult.error('Please log in to submit a report');
      }

      final currentUser = _authService.currentUser!;
      
      // Determine priority based on category
      String priority = _determinePriority(category);
      
      // Insert report into database
      final response = await _supabase.from('reports').insert({
        'user_id': currentUser['id'],
        'title': title,
        'description': description,
        'category': category,
        'location': location,
        'latitude': latitude,
        'longitude': longitude,
        'image_urls': imageUrls ?? [],
        'contact_number': contactNumber ?? currentUser['phone_number'],
        'priority': priority,
        'status': 'submitted',
        'created_at': DateTime.now().toIso8601String(),
        'updated_at': DateTime.now().toIso8601String(),
      }).select().single();

      final reportId = response['id'].toString();
      
      print('Report submitted successfully: $reportId');
      print('User: ${currentUser['full_name']} (${currentUser['email']})');
      
      return ReportSubmissionResult.success(
        reportId: reportId,
        message: 'Report submitted successfully with $priority priority',
        priority: priority,
      );
    } catch (e) {
      print('Error submitting report: $e');
      return ReportSubmissionResult.error('Failed to submit report: ${e.toString()}');
    }
  }

  // Get current user's reports only
  Future<List<ReportModel>> getUserReports() async {
    try {
      if (!_authService.isLoggedIn) {
        throw Exception('User not logged in');
      }

      final reports = await _supabase
          .from('reports')
          .select('*')
          .eq('user_id', _authService.currentUser!['id'])
          .order('created_at', ascending: false);

      print('Retrieved ${reports.length} reports for user: ${_authService.currentUser!['email']}');
      
      return reports.map<ReportModel>((json) => ReportModel.fromJson(json)).toList();
    } catch (e) {
      print('Error fetching user reports: $e');
      return [];
    }
  }

  // Get all reports with user info (admin only)
  Future<List<ReportModel>> getAllReports() async {
    try {
      if (!_authService.isLoggedIn || !_authService.isAdmin) {
        throw Exception('Admin access required');
      }

      final reports = await _supabase
          .from('reports')
          .select('''
            *,
            users!inner(full_name, email, phone_number)
          ''')
          .order('created_at', ascending: false);

      print('Admin retrieved ${reports.length} total reports');
      
      return reports.map<ReportModel>((json) => ReportModel.fromJsonWithUser(json)).toList();
    } catch (e) {
      print('Error fetching all reports: $e');
      return [];
    }
  }

  // Update report status (admin only)
  Future<bool> updateReportStatus({
    required String reportId,
    required String newStatus,
    String? adminNotes,
  }) async {
    try {
      if (!_authService.isLoggedIn || !_authService.isAdmin) {
        throw Exception('Admin access required');
      }

      await _supabase
          .from('reports')
          .update({
        'status': newStatus,
        'admin_notes': adminNotes,
        'updated_at': DateTime.now().toIso8601String(),
        if (newStatus == 'resolved') 'completion_date': DateTime.now().toIso8601String(),
      }).eq('id', reportId);

      return true;
    } catch (e) {
      print('Error updating report status: $e');
      return false;
    }
  }

  // Get categories
  Future<List<CategoryModel>> getCategories() async {
    try {
      final response = await _supabase
          .from('categories')
          .select()
          .eq('is_active', true)
          .order('display_name');

      return response.map<CategoryModel>((json) => CategoryModel.fromJson(json)).toList();
    } catch (e) {
      print('Error fetching categories: $e');
      return _getDefaultCategories();
    }
  }

  // Private helper to determine priority
  String _determinePriority(String category) {
    switch (category) {
      case 'public_safety':
        return 'urgent';
      case 'water_sewage':
      case 'electricity_streetlights':
        return 'high';
      case 'roads':
      case 'waste_management':
      case 'public_transport':
        return 'medium';
      default:
        return 'low';
    }
  }

  // Default categories
  List<CategoryModel> _getDefaultCategories() {
    return [
      CategoryModel(id: 1, name: 'roads', displayName: 'Roads & Infrastructure'),
      CategoryModel(id: 2, name: 'water_sewage', displayName: 'Water & Sewage'),
      CategoryModel(id: 3, name: 'electricity_streetlights', displayName: 'Electricity & Street Lights'),
      CategoryModel(id: 4, name: 'waste_management', displayName: 'Waste Management'),
      CategoryModel(id: 5, name: 'public_safety', displayName: 'Public Safety'),
      CategoryModel(id: 6, name: 'parks_recreation', displayName: 'Parks & Recreation'),
      CategoryModel(id: 7, name: 'public_transport', displayName: 'Public Transport'),
      CategoryModel(id: 8, name: 'noise_pollution', displayName: 'Noise Pollution'),
      CategoryModel(id: 9, name: 'environmental', displayName: 'Environmental Issues'),
      CategoryModel(id: 10, name: 'other', displayName: 'Other Issues'),
    ];
  }
}

// Report Model
class ReportModel {
  final String id;
  final String userId;
  final String title;
  final String description;
  final String category;
  final String location;
  final double? latitude;
  final double? longitude;
  final List<String> imageUrls;
  final String status;
  final String priority;
  final DateTime createdAt;
  final DateTime updatedAt;
  final String? contactNumber;
  final String? adminNotes;
  final DateTime? completionDate;
  
  // User information (for admin view)
  final String? userName;
  final String? userEmail;
  final String? userPhone;

  ReportModel({
    required this.id,
    required this.userId,
    required this.title,
    required this.description,
    required this.category,
    required this.location,
    this.latitude,
    this.longitude,
    required this.imageUrls,
    required this.status,
    required this.priority,
    required this.createdAt,
    required this.updatedAt,
    this.contactNumber,
    this.adminNotes,
    this.completionDate,
    this.userName,
    this.userEmail,
    this.userPhone,
  });

  factory ReportModel.fromJson(Map<String, dynamic> json) {
    List<String> imageUrls = [];
    if (json['image_urls'] != null && json['image_urls'] is List) {
      imageUrls = List<String>.from(json['image_urls']);
    }

    return ReportModel(
      id: json['id'].toString(),
      userId: json['user_id'].toString(),
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      category: json['category'] ?? '',
      location: json['location'] ?? '',
      latitude: json['latitude']?.toDouble(),
      longitude: json['longitude']?.toDouble(),
      imageUrls: imageUrls,
      status: json['status'] ?? 'submitted',
      priority: json['priority'] ?? 'medium',
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
      contactNumber: json['contact_number'],
      adminNotes: json['admin_notes'],
      completionDate: json['completion_date'] != null 
          ? DateTime.parse(json['completion_date']) 
          : null,
    );
  }

  factory ReportModel.fromJsonWithUser(Map<String, dynamic> json) {
    final report = ReportModel.fromJson(json);
    final userInfo = json['users'] ?? {};
    
    return ReportModel(
      id: report.id,
      userId: report.userId,
      title: report.title,
      description: report.description,
      category: report.category,
      location: report.location,
      latitude: report.latitude,
      longitude: report.longitude,
      imageUrls: report.imageUrls,
      status: report.status,
      priority: report.priority,
      createdAt: report.createdAt,
      updatedAt: report.updatedAt,
      contactNumber: report.contactNumber,
      adminNotes: report.adminNotes,
      completionDate: report.completionDate,
      userName: userInfo['full_name'],
      userEmail: userInfo['email'],
      userPhone: userInfo['phone_number'],
    );
  }
}

// Category Model
class CategoryModel {
  final int id;
  final String name;
  final String displayName;

  CategoryModel({
    required this.id,
    required this.name,
    required this.displayName,
  });

  factory CategoryModel.fromJson(Map<String, dynamic> json) {
    return CategoryModel(
      id: json['id'],
      name: json['name'] ?? '',
      displayName: json['display_name'] ?? '',
    );
  }
}

// Report Submission Result
class ReportSubmissionResult {
  final bool success;
  final String? reportId;
  final String message;
  final String? priority;

  ReportSubmissionResult._({
    required this.success,
    this.reportId,
    required this.message,
    this.priority,
  });

  factory ReportSubmissionResult.success({
    required String reportId,
    required String message,
    String? priority,
  }) {
    return ReportSubmissionResult._(
      success: true,
      reportId: reportId,
      message: message,
      priority: priority,
    );
  }

  factory ReportSubmissionResult.error(String message) {
    return ReportSubmissionResult._(
      success: false,
      reportId: null,
      message: message,
      priority: null,
    );
  }
}