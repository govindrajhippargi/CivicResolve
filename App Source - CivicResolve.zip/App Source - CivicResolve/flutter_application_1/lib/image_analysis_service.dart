import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:google_generative_ai/google_generative_ai.dart';

class ImageAnalysisService {
  static const String _apiKey = 'AIzaSyC2kPThYyYT3UmKF-6uPEF3qTeSbAmicG8';
  static GenerativeModel? _model;
  
  static GenerativeModel get _geminiModel {
    _model ??= GenerativeModel(
      model: 'gemini-1.5-flash',
      apiKey: _apiKey,
      generationConfig: GenerationConfig(
        temperature: 0.1,
        topK: 40,
        topP: 0.95,
        maxOutputTokens: 1024,
      ),
      safetySettings: [
        SafetySetting(HarmCategory.harassment, HarmBlockThreshold.none),
        SafetySetting(HarmCategory.hateSpeech, HarmBlockThreshold.none),
        SafetySetting(HarmCategory.sexuallyExplicit, HarmBlockThreshold.none),
        SafetySetting(HarmCategory.dangerousContent, HarmBlockThreshold.none),
      ],
    );
    return _model!;
  }

  static const Map<String, List<String>> _disasterKeywords = {
    'fire': ['fire', 'flames', 'burning', 'smoke', 'ash', 'charred', 'burnt', 'blaze', 'explosion'],
    'flood': ['flood', 'water damage', 'flooding', 'overflow', 'submerged', 'muddy water'],
    'earthquake': ['earthquake', 'collapsed', 'rubble', 'debris', 'structural damage', 'cracks'],
    'storm': ['storm', 'hurricane', 'tornado', 'wind damage', 'uprooted trees', 'roof damage'],
    'emergency': ['emergency', 'disaster', 'catastrophe', 'crisis', 'urgent', 'evacuation']
  };

  static Future<String> analyzeImageForPriority(File imageFile, {String? description}) async {
    try {
      print('🔍 Starting Gemini AI analysis...');
      
      if (description != null && description.isNotEmpty) {
        final urgentCheck = _checkUrgentKeywords(description);
        if (urgentCheck) {
          print('⚠️ Urgent keywords detected in description');
          return 'High';
        }
      }

      Uint8List imageBytes = await imageFile.readAsBytes();
      
      final prompt = _buildAnalysisPrompt(description);
      final content = [
        Content.multi([
          TextPart(prompt),
          DataPart('image/jpeg', imageBytes),
        ])
      ];

      String? result;
      for (int attempt = 1; attempt <= 3; attempt++) {
        try {
          print('🤖 Gemini attempt $attempt/3...');
          final response = await _geminiModel.generateContent(content);
          
          if (response.text != null && response.text!.isNotEmpty) {
            result = response.text!;
            break;
          }
        } catch (e) {
          print('❌ Attempt $attempt failed: $e');
          if (attempt == 3) throw e;
          await Future.delayed(Duration(seconds: attempt * 2));
        }
      }

      if (result == null) {
        throw Exception('No valid response from Gemini');
      }

      print('🤖 Gemini response: ${result.substring(0, result.length > 100 ? 100 : result.length)}...');
      
      final priority = _parseResponse(result);
      
      // Additional safety check: if Gemini mentions any disaster but assigns low priority, override to High
      final resultUpper = result.toUpperCase();
      final disasterMentioned = ['FLOOD', 'FIRE', 'EARTHQUAKE', 'STORM', 'DISASTER', 'EMERGENCY', 'DAMAGE'].any((term) => resultUpper.contains(term));
      
      if (disasterMentioned && priority == 'Low') {
        print('🚨 OVERRIDE: Disaster detected but priority was Low - forcing HIGH priority');
        return 'High';
      }
      
      print('✅ Analysis complete. Priority: $priority');
      return priority;
      
    } catch (e) {
      print('❌ Gemini analysis failed: $e');
      
      if (description != null && description.isNotEmpty) {
        final fallback = _fallbackAnalysis(description);
        print('🔄 Using fallback analysis: $fallback');
        return fallback;
      }
      
      return 'Medium';
    }
  }

  static String _buildAnalysisPrompt(String? description) {
    return '''
You are a DISASTER EMERGENCY ANALYST. Analyze this image for natural disasters and emergencies.

🚨 CRITICAL RULES:
- ANY natural disaster = IMMEDIATE HIGH PRIORITY
- ANY man-made disaster = IMMEDIATE HIGH PRIORITY  
- ANY emergency situation = IMMEDIATE HIGH PRIORITY

DISASTER CATEGORIES (ALL HIGH PRIORITY):
🔥 FIRE/EXPLOSION: Any flames, smoke, burnt areas, fire damage, explosions
🌊 FLOOD: Any water damage, flooding, submerged roads/buildings, storm surge  
🏚️ EARTHQUAKE: Any collapsed buildings, structural damage, cracks, debris
🌪️ STORM: Any wind damage, fallen trees, tornado damage, hurricane effects
⚠️ EMERGENCY: Any dangerous situation, infrastructure damage, hazardous conditions

${description != null ? 'CONTEXT: $description' : ''}

STRICT RESPONSE FORMAT:
PRIORITY: HIGH/MEDIUM/LOW
DISASTER_TYPE: [Fire/Flood/Earthquake/Storm/Emergency/None]
REASONING: [Why this priority was assigned]

IMPORTANT: If you see ANY signs of natural disasters, flooding, fire, structural damage, or emergencies - ALWAYS respond with HIGH priority. Only use LOW for minor maintenance issues with no safety risk.
''';
  }

  static String _parseResponse(String response) {
    final upper = response.toUpperCase();
    
    // Check for explicit disaster types mentioned - ALL should be HIGH
    final disasterIndicators = [
      'FIRE', 'FLAMES', 'SMOKE', 'BURNING', 'EXPLOSION',
      'FLOOD', 'FLOODING', 'WATER DAMAGE', 'SUBMERGED', 'INUNDATION',
      'EARTHQUAKE', 'COLLAPSED', 'STRUCTURAL DAMAGE', 'DEBRIS',
      'STORM', 'HURRICANE', 'TORNADO', 'WIND DAMAGE',
      'EMERGENCY', 'DISASTER', 'CATASTROPHE', 'EVACUATION'
    ];
    
    // If ANY disaster keyword is found, force HIGH priority
    for (var indicator in disasterIndicators) {
      if (upper.contains(indicator)) {
        print('🚨 Disaster detected: $indicator - Forcing HIGH priority');
        return 'High';
      }
    }
    
    // Check for explicit priority statements
    if (upper.contains('PRIORITY: HIGH') || 
        (upper.contains('HIGH') && (upper.contains('SEVERE') || upper.contains('EMERGENCY')))) {
      return 'High';
    }
    
    if (upper.contains('PRIORITY: LOW') || 
        (upper.contains('LOW') && upper.contains('MINOR'))) {
      return 'Low';
    }
    
    // Default to Medium, but this should rarely happen with natural disasters
    return 'Medium';
  }

  static bool _checkUrgentKeywords(String description) {
    final lower = description.toLowerCase();
    
    // All natural disasters should trigger urgent response
    final disasterKeywords = [
      'emergency', 'urgent', 'disaster', 'catastrophe',
      'fire', 'flames', 'burning', 'smoke', 'explosion', 'blaze',
      'flood', 'flooding', 'water damage', 'submerged', 'inundation',
      'earthquake', 'collapse', 'structural damage', 'debris',
      'storm', 'hurricane', 'tornado', 'wind damage',
      'severe', 'major', 'critical', 'evacuation', 'rescue'
    ];
    
    for (var keyword in disasterKeywords) {
      if (lower.contains(keyword)) {
        print('🚨 Urgent keyword detected: $keyword');
        return true;
      }
    }
    
    return false;
  }

  static String _fallbackAnalysis(String description) {
    final lower = description.toLowerCase();
    
    // Check for disaster keywords - if found, immediately return High
    final disasterKeywords = [
      'fire', 'flames', 'burning', 'smoke', 'explosion',
      'flood', 'flooding', 'water damage', 'submerged',
      'earthquake', 'collapse', 'structural damage',
      'storm', 'hurricane', 'tornado', 'wind damage',
      'emergency', 'disaster', 'catastrophe', 'evacuation'
    ];
    
    for (var keyword in disasterKeywords) {
      if (lower.contains(keyword)) {
        print('🚨 Fallback detected disaster keyword: $keyword - Assigning HIGH priority');
        return 'High';
      }
    }
    
    // Only if no disaster keywords, use scoring system
    int score = 0;
    for (var keywords in _disasterKeywords.values) {
      for (var keyword in keywords) {
        if (lower.contains(keyword)) score += 3; // Increased score
      }
    }
    
    if (lower.contains('severe') || lower.contains('major')) score += 4;
    if (lower.contains('critical') || lower.contains('urgent')) score += 5;
    
    if (score >= 3) return 'High'; // Lowered threshold
    if (score >= 1) return 'Medium';
    return 'Low';
  }

  static Future<bool> testGeminiConnection() async {
    try {
      final response = await _geminiModel.generateContent([Content.text('Test')]);
      return response.text != null && response.text!.isNotEmpty;
    } catch (e) {
      print('Connection test failed: $e');
      return false;
    }
  }

  static Map<String, dynamic> getAnalysisInfo() {
    return {
      'apiKey': _apiKey.substring(0, 10) + '...',
      'model': 'gemini-1.5-flash',
      'disasterTypes': _disasterKeywords.keys.toList(),
    };
  }

  static Map<String, String> analyzeDescriptionForPriority(String description) {
    final analysis = _fallbackAnalysis(description);
    return {
      'priority': analysis,
      'explanation': 'Analysis based on keywords in description',
    };
  }

  static Color getPriorityColor(String priority) {
    switch (priority.toLowerCase()) {
      case 'high': return const Color(0xFFEF4444);
      case 'medium': return const Color(0xFFF59E0B);
      case 'low': return const Color(0xFF10B981);
      default: return const Color(0xFF6B7280);
    }
  }

  static String getPriorityExplanation(String priority) {
    switch (priority.toLowerCase()) {
      case 'high':
        return 'High priority: Immediate emergency response required. This represents a serious threat to public safety or infrastructure.';
      case 'medium':
        return 'Medium priority: Significant issue requiring timely attention. May pose potential risks if not addressed.';
      case 'low':
        return 'Low priority: Minor issue or routine maintenance. No immediate danger to public safety.';
      default:
        return 'Priority assessment pending. Please check analysis results.';
    }
  }
}