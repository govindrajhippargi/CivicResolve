import 'dart:convert';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'auth_service.dart';

class EnhancedReportService {
  static final SupabaseClient _supabase = Supabase.instance.client;
  static final AuthService _authService = AuthService.instance;
  static EnhancedReportService? _instance;
  static EnhancedReportService get instance =>
      _instance ??= EnhancedReportService._();

  EnhancedReportService._();

  // Submit a new report with automatic priority assignment
  Future<ReportSubmissionResult> submitReport({
    required String title,
    required String description,
    required String category,
    required String location,
    double? latitude,
    double? longitude,
    List<String>? imageUrls,
    String? contactNumber,
  }) async {
    try {
      // Check if user is logged in
      if (!_authService.isLoggedIn) {
        return ReportSubmissionResult.error('Please log in to submit a report');
      }

      final currentUser = _authService.userEmail;
      if (currentUser == null) {
        return ReportSubmissionResult.error('User not logged in');
      }

      // Use the enhanced RPC function for automatic priority assignment
      final response = await _supabase.rpc(
        'submit_report_with_priority',
        params: {
          'p_user_id': currentUser, // Using email as user ID
          'p_title': title,
          'p_description': description,
          'p_category': category,
          'p_location': location,
          'p_latitude': latitude,
          'p_longitude': longitude,
          'p_image_urls': imageUrls ?? [],
          'p_contact_number': contactNumber,
        },
      );

      if (response != null && response.isNotEmpty) {
        final result = response[0];
        if (result['success'] == true) {
          return ReportSubmissionResult.success(
            reportId: result['report_id'].toString(),
            message: result['message'] ?? 'Report submitted successfully',
            priority: result['assigned_priority'],
          );
        } else {
          return ReportSubmissionResult.error(
            result['message'] ?? 'Failed to submit report',
          );
        }
      } else {
        return ReportSubmissionResult.error('Invalid response from server');
      }
    } catch (e) {
      print('Error submitting report: $e');
      return ReportSubmissionResult.error(
        'Failed to submit report: ${e.toString()}',
      );
    }
  }

  // Get user's reports
  Future<List<EnhancedReportModel>> getUserReports({String? status}) async {
    try {
      if (!_authService.isLoggedIn) {
        throw Exception('User not logged in');
      }

      var query = _supabase
          .from('reports')
          .select('''
            *, 
            users!inner(full_name, email, phone_number),
            categories(display_name, icon_name, color_code)
          ''')
          .eq('user_id', _authService.userEmail ?? '');

      if (status != null) {
        query = query.eq('status', status);
      }

      final response = await query.order('created_at', ascending: false);

      return response
          .map<EnhancedReportModel>(
            (json) => EnhancedReportModel.fromJson(json),
          )
          .toList();
    } catch (e) {
      print('Error fetching user reports: $e');
      return [];
    }
  }

  // Get all reports (for admin view)
  Future<List<EnhancedReportModel>> getAllReports({
    String? status,
    String? category,
    String? priority,
    int? limit,
  }) async {
    try {
      if (!_authService.isLoggedIn || !_authService.isAdmin) {
        throw Exception('Admin access required');
      }

      // Use the enhanced RPC function for priority-aware querying
      final response = await _supabase.rpc(
        'get_reports_by_priority',
        params: {
          'p_priority': priority,
          'p_status': status,
          'p_limit': limit ?? 50,
          'p_offset': 0,
        },
      );

      return response
          .map<EnhancedReportModel>(
            (json) => EnhancedReportModel.fromRPCResponse(json),
          )
          .toList();
    } catch (e) {
      print('Error fetching all reports: $e');
      return [];
    }
  }

  // Update report status (admin only)
  Future<bool> updateReportStatus({
    required String reportId,
    required String newStatus,
    String? reason,
    String? assignedOfficerId,
    DateTime? estimatedCompletion,
  }) async {
    try {
      if (!_authService.isLoggedIn || !_authService.isAdmin) {
        throw Exception('Admin access required');
      }

      final updateData = <String, dynamic>{
        'status': newStatus,
        'updated_at': DateTime.now().toIso8601String(),
      };

      if (assignedOfficerId != null) {
        updateData['assigned_officer_id'] = assignedOfficerId;
      }

      if (estimatedCompletion != null) {
        updateData['estimated_completion_date'] = estimatedCompletion
            .toIso8601String();
      }

      if (newStatus == 'resolved') {
        updateData['completion_date'] = DateTime.now().toIso8601String();
      }

      await _supabase.from('reports').update(updateData).eq('id', reportId);

      // Get report details for notification
      final reportResponse = await _supabase
          .from('reports')
          .select('user_id, title')
          .eq('id', reportId)
          .single();

      // Send notification to user
      await sendNotificationToUser(
        userId: reportResponse['user_id'],
        reportId: reportId,
        title: 'Report Status Updated',
        message:
            'Your report "${reportResponse['title']}" status has been changed to $newStatus',
        type: 'status_update',
      );

      return true;
    } catch (e) {
      print('Error updating report status: $e');
      return false;
    }
  }

  // Send notification to user
  Future<bool> sendNotificationToUser({
    required String userId,
    String? reportId,
    required String title,
    required String message,
    String type = 'admin_message',
  }) async {
    try {
      if (!_authService.isLoggedIn || !_authService.isAdmin) {
        throw Exception('Admin access required');
      }

      await _supabase.from('notifications').insert({
        'user_id': userId,
        'report_id': reportId,
        'title': title,
        'message': message,
        'type': type,
        'created_at': DateTime.now().toIso8601String(),
      });

      return true;
    } catch (e) {
      print('Error sending notification: $e');
      return false;
    }
  }

  // Get user notifications
  Future<List<NotificationModel>> getUserNotifications({bool? isRead}) async {
    try {
      if (!_authService.isLoggedIn) {
        throw Exception('User not logged in');
      }

      var query = _supabase
          .from('notifications')
          .select()
          .eq('user_id', _authService.userEmail ?? '');

      if (isRead != null) {
        query = query.eq('is_read', isRead);
      }

      final response = await query.order('created_at', ascending: false);

      return response
          .map<NotificationModel>((json) => NotificationModel.fromJson(json))
          .toList();
    } catch (e) {
      print('Error fetching notifications: $e');
      return [];
    }
  }

  // Mark notification as read
  Future<bool> markNotificationAsRead(String notificationId) async {
    try {
      await _supabase
          .from('notifications')
          .update({'is_read': true})
          .eq('id', notificationId);

      return true;
    } catch (e) {
      print('Error marking notification as read: $e');
      return false;
    }
  }

  // Get categories
  Future<List<CategoryModel>> getCategories() async {
    try {
      final response = await _supabase
          .from('categories')
          .select()
          .eq('is_active', true)
          .order('display_name');

      return response
          .map<CategoryModel>((json) => CategoryModel.fromJson(json))
          .toList();
    } catch (e) {
      print('Error fetching categories: $e');
      // Return default categories if database fails
      return _getDefaultCategories();
    }
  }

  // Get priority statistics for external access
  Future<Map<String, dynamic>> getPriorityStatistics({
    String? timePeriod = 'all',
    String? category,
  }) async {
    try {
      final response = await _supabase.rpc(
        'get_priority_statistics',
        params: {'p_time_period': timePeriod, 'p_category': category},
      );

      return {'success': true, 'data': response};
    } catch (e) {
      print('Error fetching priority statistics: $e');
      return {'success': false, 'error': e.toString()};
    }
  }

  // Update report priority (admin only)
  Future<bool> updateReportPriority({
    required String reportId,
    required String newPriority,
    String? reason,
  }) async {
    try {
      if (!_authService.isLoggedIn || !_authService.isAdmin) {
        throw Exception('Admin access required');
      }

      final response = await _supabase.rpc(
        'update_report_priority',
        params: {
          'p_report_id': int.parse(reportId),
          'p_new_priority': newPriority,
          'p_admin_id': _authService.userEmail ?? 'admin',
          'p_reason': reason,
        },
      );

      if (response.isNotEmpty) {
        return response[0]['success'] ?? false;
      }
      return false;
    } catch (e) {
      print('Error updating report priority: $e');
      return false;
    }
  }

  // Get priority dashboard data for external access
  Future<Map<String, dynamic>> getPriorityDashboard() async {
    try {
      final response = await _supabase.rpc('get_priority_dashboard');

      if (response.isNotEmpty) {
        return {'success': true, 'data': response[0]};
      }
      return {'success': false, 'error': 'No data returned'};
    } catch (e) {
      print('Error fetching priority dashboard: $e');
      return {'success': false, 'error': e.toString()};
    }
  }

  List<CategoryModel> _getDefaultCategories() {
    return [
      CategoryModel(
        id: 1,
        name: 'roads',
        displayName: 'Roads & Infrastructure',
        isActive: true,
        iconName: 'road',
        colorCode: '#FF5722',
      ),
      CategoryModel(
        id: 2,
        name: 'water_sewage',
        displayName: 'Water & Sewage',
        isActive: true,
        iconName: 'water_drop',
        colorCode: '#2196F3',
      ),
      CategoryModel(
        id: 3,
        name: 'electricity_streetlights',
        displayName: 'Electricity & Street Lights',
        isActive: true,
        iconName: 'lightbulb',
        colorCode: '#FFC107',
      ),
      CategoryModel(
        id: 4,
        name: 'waste_management',
        displayName: 'Waste Management',
        isActive: true,
        iconName: 'delete',
        colorCode: '#4CAF50',
      ),
      CategoryModel(
        id: 5,
        name: 'public_safety',
        displayName: 'Public Safety',
        isActive: true,
        iconName: 'security',
        colorCode: '#F44336',
      ),
      CategoryModel(
        id: 6,
        name: 'parks_recreation',
        displayName: 'Parks & Recreation',
        isActive: true,
        iconName: 'park',
        colorCode: '#8BC34A',
      ),
      CategoryModel(
        id: 7,
        name: 'public_transport',
        displayName: 'Public Transport',
        isActive: true,
        iconName: 'directions_bus',
        colorCode: '#9C27B0',
      ),
      CategoryModel(
        id: 8,
        name: 'noise_pollution',
        displayName: 'Noise Pollution',
        isActive: true,
        iconName: 'volume_up',
        colorCode: '#607D8B',
      ),
      CategoryModel(
        id: 9,
        name: 'environmental',
        displayName: 'Environmental Issues',
        isActive: true,
        iconName: 'eco',
        colorCode: '#795548',
      ),
      CategoryModel(
        id: 10,
        name: 'other',
        displayName: 'Other Issues',
        isActive: true,
        iconName: 'more_horiz',
        colorCode: '#9E9E9E',
      ),
    ];
  }
}

// Enhanced Report Model with user information
class EnhancedReportModel {
  final String id;
  final String userId;
  final String title;
  final String description;
  final String category;
  final String location;
  final double? latitude;
  final double? longitude;
  final List<String> imageUrls;
  final String status;
  final String priority;
  final DateTime createdAt;
  final DateTime updatedAt;
  final String? assignedOfficerId;
  final DateTime? estimatedCompletionDate;
  final DateTime? completionDate;
  final int consolidatedReports;
  final String? contactNumber;
  final String? adminNotes;
  final String? citizenFeedback;
  final int? rating;

  // User information
  final String userName;
  final String userEmail;
  final String? userPhone;

  // Category information
  final String categoryDisplayName;
  final String? categoryIcon;
  final String? categoryColor;

  EnhancedReportModel({
    required this.id,
    required this.userId,
    required this.title,
    required this.description,
    required this.category,
    required this.location,
    this.latitude,
    this.longitude,
    required this.imageUrls,
    required this.status,
    required this.priority,
    required this.createdAt,
    required this.updatedAt,
    this.assignedOfficerId,
    this.estimatedCompletionDate,
    this.completionDate,
    required this.consolidatedReports,
    this.contactNumber,
    this.adminNotes,
    this.citizenFeedback,
    this.rating,
    required this.userName,
    required this.userEmail,
    this.userPhone,
    required this.categoryDisplayName,
    this.categoryIcon,
    this.categoryColor,
  });

  factory EnhancedReportModel.fromJson(Map<String, dynamic> json) {
    // Handle image_urls from JSONB format
    List<String> imageUrls = [];
    if (json['image_urls'] != null) {
      if (json['image_urls'] is List) {
        imageUrls = List<String>.from(json['image_urls']);
      } else if (json['image_urls'] is String) {
        try {
          final parsed = jsonDecode(json['image_urls']);
          if (parsed is List) {
            imageUrls = List<String>.from(parsed);
          }
        } catch (e) {
          print('Error parsing image URLs: $e');
        }
      }
    }

    // Extract user information
    final userInfo = json['users'] ?? {};
    final categoryInfo = json['categories'] ?? {};

    return EnhancedReportModel(
      id: json['id'].toString(),
      userId: json['user_id'].toString(),
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      category: json['category'] ?? '',
      location: json['location'] ?? '',
      latitude: json['latitude']?.toDouble(),
      longitude: json['longitude']?.toDouble(),
      imageUrls: imageUrls,
      status: json['status'] ?? 'submitted',
      priority: json['priority'] ?? 'medium',
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
      assignedOfficerId: json['assigned_officer_id']?.toString(),
      estimatedCompletionDate: json['estimated_completion_date'] != null
          ? DateTime.parse(json['estimated_completion_date'])
          : null,
      completionDate: json['completion_date'] != null
          ? DateTime.parse(json['completion_date'])
          : null,
      consolidatedReports: json['consolidated_reports'] ?? 1,
      contactNumber: json['contact_number'],
      adminNotes: json['admin_notes'],
      citizenFeedback: json['citizen_feedback'],
      rating: json['rating'],
      userName: userInfo['full_name'] ?? '',
      userEmail: userInfo['email'] ?? '',
      userPhone: userInfo['phone_number'],
      categoryDisplayName:
          categoryInfo['display_name'] ?? json['category'] ?? '',
      categoryIcon: categoryInfo['icon_name'],
      categoryColor: categoryInfo['color_code'],
    );
  }

  // Alternative factory for RPC response format
  factory EnhancedReportModel.fromRPCResponse(Map<String, dynamic> json) {
    return EnhancedReportModel(
      id: json['report_id'].toString(),
      userId: '', // Not included in RPC response
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      category: json['category'] ?? '',
      location: json['location'] ?? '',
      latitude: null, // Not included in basic RPC response
      longitude: null, // Not included in basic RPC response
      imageUrls: [], // Not included in basic RPC response
      status: json['status'] ?? 'submitted',
      priority: json['priority'] ?? 'medium',
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
      assignedOfficerId: null,
      estimatedCompletionDate: json['estimated_completion_date'] != null
          ? DateTime.parse(json['estimated_completion_date'])
          : null,
      completionDate: json['completion_date'] != null
          ? DateTime.parse(json['completion_date'])
          : null,
      consolidatedReports: 1,
      contactNumber: json['contact_number'],
      adminNotes: json['admin_notes'],
      citizenFeedback: null,
      rating: null,
      userName: json['user_name'] ?? '',
      userEmail: json['user_email'] ?? '',
      userPhone: null,
      categoryDisplayName: json['category'] ?? '',
      categoryIcon: null,
      categoryColor: null,
    );
  }
}

// Notification Model
class NotificationModel {
  final String id;
  final String userId;
  final String? reportId;
  final String title;
  final String message;
  final String type;
  final bool isRead;
  final DateTime createdAt;

  NotificationModel({
    required this.id,
    required this.userId,
    this.reportId,
    required this.title,
    required this.message,
    required this.type,
    required this.isRead,
    required this.createdAt,
  });

  factory NotificationModel.fromJson(Map<String, dynamic> json) {
    return NotificationModel(
      id: json['id'].toString(),
      userId: json['user_id'].toString(),
      reportId: json['report_id']?.toString(),
      title: json['title'] ?? '',
      message: json['message'] ?? '',
      type: json['type'] ?? '',
      isRead: json['is_read'] ?? false,
      createdAt: DateTime.parse(json['created_at']),
    );
  }
}

// Category Model
class CategoryModel {
  final int id;
  final String name;
  final String displayName;
  final String? description;
  final String? iconName;
  final String? colorCode;
  final bool isActive;

  CategoryModel({
    required this.id,
    required this.name,
    required this.displayName,
    this.description,
    this.iconName,
    this.colorCode,
    required this.isActive,
  });

  factory CategoryModel.fromJson(Map<String, dynamic> json) {
    return CategoryModel(
      id: json['id'],
      name: json['name'] ?? '',
      displayName: json['display_name'] ?? '',
      description: json['description'],
      iconName: json['icon_name'],
      colorCode: json['color_code'],
      isActive: json['is_active'] ?? true,
    );
  }
}

// Report Submission Result
class ReportSubmissionResult {
  final bool success;
  final String? reportId;
  final String message;
  final String? priority;

  ReportSubmissionResult._({
    required this.success,
    this.reportId,
    required this.message,
    this.priority,
  });

  factory ReportSubmissionResult.success({
    required String reportId,
    required String message,
    String? priority,
  }) {
    return ReportSubmissionResult._(
      success: true,
      reportId: reportId,
      message: message,
      priority: priority,
    );
  }

  factory ReportSubmissionResult.error(String message) {
    return ReportSubmissionResult._(
      success: false,
      reportId: null,
      message: message,
      priority: null,
    );
  }
}
