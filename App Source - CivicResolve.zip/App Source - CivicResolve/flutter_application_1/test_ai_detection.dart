import 'lib/image_analysis_service.dart';

void main() {
  print('Testing Enhanced AI Detection for Infrastructure Damage');
  print('=========================================================');
  
  final service = ImageAnalysisService();
  
  // Test scenario 1: Bridge collapse detection
  print('\n1. Testing Bridge Collapse Detection:');
  final bridgeLabels = ['bridge', 'collapse', 'damaged', 'structure'];
  final bridgeObjects = ['Vehicle', 'Building'];
  final bridgeText = 'DANGER: Bridge collapse ahead, road closed';
  
  final bridgePriority = service.calculatePriorityFromAnalysis(
    bridgeLabels, 
    bridgeObjects, 
    bridgeText
  );
  print('   Labels: $bridgeLabels');
  print('   Objects: $bridgeObjects');
  print('   Text: "$bridgeText"');
  print('   Result: ${bridgePriority['priority']} Priority (Score: ${bridgePriority['score']})');
  print('   Explanation: ${bridgePriority['explanation']}');
  
  // Test scenario 2: Building structural damage
  print('\n2. Testing Building Structural Damage:');
  final buildingLabels = ['building', 'damage', 'structural', 'crack'];
  final buildingObjects = ['Building', 'Wall'];
  final buildingText = 'Structural damage visible on building facade';
  
  final buildingPriority = service.calculatePriorityFromAnalysis(
    buildingLabels, 
    buildingObjects, 
    buildingText
  );
  print('   Labels: $buildingLabels');
  print('   Objects: $buildingObjects');
  print('   Text: "$buildingText"');
  print('   Result: ${buildingPriority['priority']} Priority (Score: ${buildingPriority['score']})');
  print('   Explanation: ${buildingPriority['explanation']}');
  
  // Test scenario 3: Road infrastructure damage
  print('\n3. Testing Road Infrastructure Damage:');
  final roadLabels = ['road', 'pothole', 'damage', 'asphalt'];
  final roadObjects = ['Vehicle', 'Road'];
  final roadText = 'Large pothole causing traffic issues';
  
  final roadPriority = service.calculatePriorityFromAnalysis(
    roadLabels, 
    roadObjects, 
    roadText
  );
  print('   Labels: $roadLabels');
  print('   Objects: $roadObjects');
  print('   Text: "$roadText"');
  print('   Result: ${roadPriority['priority']} Priority (Score: ${roadPriority['score']})');
  print('   Explanation: ${roadPriority['explanation']}');
  
  // Test scenario 4: Minor issue (should be low priority)
  print('\n4. Testing Minor Issue:');
  final minorLabels = ['litter', 'trash', 'street'];
  final minorObjects = ['Plastic bag', 'Paper'];
  final minorText = 'Some litter on the sidewalk';
  
  final minorPriority = service.calculatePriorityFromAnalysis(
    minorLabels, 
    minorObjects, 
    minorText
  );
  print('   Labels: $minorLabels');
  print('   Objects: $minorObjects');
  print('   Text: "$minorText"');
  print('   Result: ${minorPriority['priority']} Priority (Score: ${minorPriority['score']})');
  print('   Explanation: ${minorPriority['explanation']}');
  
  print('\n=========================================================');
  print('Enhanced AI Detection Test Complete!');
  print('✅ Bridge collapses and major infrastructure damage should be HIGH priority');
  print('✅ Minor issues should be LOW priority');
  print('✅ Enhanced scoring system working correctly');
}