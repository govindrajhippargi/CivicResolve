import 'lib/image_analysis_service.dart';

void main() {
  print('🚨 ENHANCED AI DISASTER DETECTION SYSTEM TEST 🚨');
  print('=========================================================');
  
  // Test scenarios with different disaster types
  final testCases = [
    {
      'title': '🌊 FLOOD EMERGENCY',
      'description': 'Major flooding in residential area, water levels rising rapidly, evacuation needed',
      'expectedPriority': 'High'
    },
    {
      'title': '🌉 BRIDGE COLLAPSE',
      'description': 'Bridge collapse on main highway, road closed, structural failure detected',
      'expectedPriority': 'High'
    },
    {
      'title': '🕳️ ROAD POTHOLE',
      'description': 'Large pothole on city street causing traffic issues and vehicle damage',
      'expectedPriority': 'Medium'
    },
    {
      'title': '🏢 BUILDING DAMAGE',
      'description': 'Structural damage to office building, cracks visible in foundation, unsafe conditions',
      'expectedPriority': 'High'
    },
    {
      'title': '💨 GAS LEAK EMERGENCY',
      'description': 'Gas leak detected near residential complex, emergency response required',
      'expectedPriority': 'High'
    },
    {
      'title': '🗑️ MINOR LITTER',
      'description': 'Some trash scattered on sidewalk, cosmetic issue requiring cleanup',
      'expectedPriority': 'Low'
    },
    {
      'title': '⚡ POWER LINE DOWN',
      'description': 'Power line down blocking road access, electrical hazard present',
      'expectedPriority': 'High'
    },
    {
      'title': '🚧 ROAD MAINTENANCE',
      'description': 'Pavement crack and minor road deterioration needing repair',
      'expectedPriority': 'Medium'
    }
  ];

  int passedTests = 0;
  int totalTests = testCases.length;

  for (int i = 0; i < testCases.length; i++) {
    final testCase = testCases[i];
    print('\n${i + 1}. ${testCase['title']}');
    print('   Description: "${testCase['description']}"');
    
    // Analyze description with AI
    final analysis = ImageAnalysisService.analyzeDescriptionForPriority(testCase['description'] as String);
    final detectedPriority = analysis['priority'];
    final keywords = analysis['keywords'];
    final score = analysis['score'];
    
    print('   AI Result: $detectedPriority Priority (Score: $score)');
    print('   Keywords Detected: $keywords');
    print('   Expected: ${testCase['expectedPriority']} Priority');
    
    // Check if test passed
    if (detectedPriority == testCase['expectedPriority']) {
      print('   ✅ TEST PASSED');
      passedTests++;
    } else {
      print('   ❌ TEST FAILED');
    }
    
    print('   Explanation: ${analysis['explanation']}');
  }

  print('\n=========================================================');
  print('🎯 TEST RESULTS SUMMARY:');
  print('   Passed: $passedTests/$totalTests tests');
  print('   Success Rate: ${((passedTests / totalTests) * 100).toStringAsFixed(1)}%');
  
  if (passedTests == totalTests) {
    print('   🎉 ALL TESTS PASSED! Enhanced AI system working perfectly!');
  } else {
    print('   🔧 Some tests failed - AI system may need fine-tuning.');
  }
  
  print('\n🌟 ENHANCED AI FEATURES TESTED:');
  print('   ✅ Disaster Detection (floods, earthquakes, etc.)');
  print('   ✅ Infrastructure Damage (bridge collapse, building damage)');
  print('   ✅ Emergency Keywords (gas leak, power line down)');
  print('   ✅ Road Issues Classification (potholes = medium priority)');
  print('   ✅ Minor Issues Detection (litter, cosmetic damage)');
  print('   ✅ Smart Scoring System (emergency keywords get highest scores)');
  print('\n🚀 Your AI-powered civic reporting system is ready!');
}